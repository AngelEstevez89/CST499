<?php
$user = 'root';
$pass = '';
$db = 'registeredstudents';

$db = new mysqli('localhost', $user, $pass, $db) or die("Sorry... keep up the hard work buddy.");
	$email = $_POST['email'];
	$password = $_POST['password'];
	$firstName = $_POST['firstName'];
	$lastName = $_POST['lastName'];
	$address = $_POST['address'];
	$phone = $_POST['phone'];


	$conn = new mysqli('localhost','root','','registeredstudents');
	if($conn->connect_error){
		die('Connection Failed : '. $conn->connect_error);
	}else{
		$stmt = $conn->prepare("Insert into registeredstudents(email, password, firstName, lastName, address, phone)
			values(?, ?, ?, ?, ?, ?)");
			$stmt->bind_param("sssssi", $email, $password, $firstName, $lastName, $address, $phone);
			$stmt->execute();
			echo "Registration Successful";
			$stmt->close();
			$conn->close();
	}

echo"Great work!!!";



?>