<?php

function check_login($con)
{

	if(isset($_SESSION['id']))
	{

		$id = $_SESSION['id'];
		$query = "select * from registeredstudents where id = '$id' limit 1";

		$result = mysqli_query($con,$query);
		if($result && mysqli_num_rows($result) > 0)
		{

			$user_data = mysqli_fetch_assoc($result);
			return $user_data;
		}
	}

	//redirect to login
	header("Location: login.php");
	die;

}

function check_notifications($con){
	$id = $_SESSION['id'];
	$query = "select * from pending_notifications where student_id = $id";

	$result = mysqli_fetch_array(mysqli_query($con, $query));
	if($result){
	$acid = $result["active_course_id"];
	if ($acid){
	$course = mysqli_fetch_array(mysqli_query($con, "select * from active_courses ac join courses c on ac.course_id = c.course_id join semesters s on ac.semester_id = s.semester_id where ac.active_course_id = $acid;"));
	$result = $course;
	}
	}
	return $result;
}

function fetch_user_courses($con){
	$id = $_SESSION['id'];
	$query = "select * from active_student_roster asr 
	join active_courses ac on asr.active_course_id = ac.active_course_id 
	join courses c on ac.course_id = c.course_id 
	join semesters s on ac.semester_id = s.semester_id
	where asr.student_id = $id";

	$result = mysqli_query($con, $query);
	if($result && mysqli_num_rows($result) > 0)
	{
		return $result;
	}
	return [];
}

function fetch_active_courses($con)
{
	$query = "select * from active_courses ac join courses c on ac.course_id = c.course_id join semesters s on ac.semester_id = s.semester_id;";

	$result = mysqli_query($con, $query);
	if($result && mysqli_num_rows($result) > 0)
	{
		return $result;
	}
	die;
}

function enroll_student($con, $course_id, $student_id){
	$course_capacity = mysqli_query($con, "select capacity from active_courses where active_course_id = $course_id;");
	$active_students = mysqli_query($con, "select count(*) from active_student_roster where course_id = $course_id;");
	if($course_capacity <= $active_students){
		// add to waitlist!
	} else {
		mysqli_query($con, "insert into active_student_roster(student_id, active_course_id) VALUES($student_id, $course_id)");
	}

}

function random_num($length)
{

	$text = "";
	if($length < 5)
	{
		$length = 5;
	}

	$len = rand(4,$length);

	for ($i=0; $i < $len; $i++) { 
		# code...

		$text .= rand(0,9);
	}

	return $text;
}