<?php
session_start();

include("connection.php");
include("functions1.php");


$user_data = check_login($con);
$course_data = fetch_user_courses($con);
$notifications = check_notifications($con);
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <title><?php echo $user_data['firstName'], ' ', $user_data['lastName']; ?></title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <style>
    /* Remove the navbar's default margin-bottom and rounded borders */
    .navbar {
      margin-bottom: 0;
      border-radius: 0;
      background-color: #EC1801;
      color: white;
    }

    /* Set height of the grid so .sidenav can be 100% (adjust as needed) */
    .row.content {
      height: 450px
    }

    /* Set gray background color and 100% height 
    sidenav {
      padding-top: 20px;
      background-color: #FF3C33;
      height: 100%;
    }
    
    /* Set black background color, white text and some padding */
    footer {
      background-color: #EC1801;
      color: white;
      padding: 15px;
    }

    h3 {
      width: 100%;
      height: 26px;
    }

    .my-profile-container {
      display: flex;
      justify-content: flex-start;
      flex-wrap: wrap;
    }

    .profile-details {
      width: 40%;
      padding: 10px;
    }

    .profile-courses {
      display: flex;
      flex-wrap: wrap;
    }

    .course {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      align-items: center;
      width: 50%;
      border: 1px solid black;

    }

    #course,
    #user {
      display: none;
    }


    /* On small screens, set height to 'auto' for sidenav and grid */
    @media screen and (max-width: 767px) {
      .sidenav {
        height: auto;
        padding: 15px;
      }

      .row.content {
        height: auto;
      }
    }
  </style>
</head>

<body>
  <nav class="navbar navbar-inverse">
    <div class="container-fluid">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a class="glyphicon glyphicon-user" href="userindex.php"></a>
      </div>
      <div class="collapse navbar-collapse" id="myNavbar">
        <ul class="nav navbar-nav">
          <li class="active"><a href="userhomepage.php">Home</a></li>
          <li><a href="userprofile.php">Profile</a></li>
          <li><a href="#">Benefits</a></li>
          <li><a href="usercontactus.php 	">Contact Us</a></li>
        </ul>
        <ul class="nav navbar-nav navbar-right">
          <li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>
        </ul>
      </div>
    </div>
  </nav>

  <div class="container-fluid text-center">
    <div class="row content">
      <div class="col-sm-2 sidenav">
        <p> Hello, <?php echo $user_data['firstName']; ?></p>
        <p><a href="#">Email</a></p>
        <p><a href="#">Calendar</a></p>
        <p><a href="courseregistry.php">Course registry</a></p>
      </div>
      <div class="col-sm-8 text-left">
        <h1>Welcome to the Profile Page</h1>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
        <hr>

        <div class='my-profile-container'>
          <div class="profile-details">
            <h3>Profile</h3>
            <p> <strong><u>Profile Details: </strong><?php echo $user_data['firstName'], ' ', $user_data['lastName']; ?></u></p>
            <p> <strong>Email: </strong><?php echo $user_data['email']; ?></p>
            <p> <strong>Password: </strong><?php echo $user_data['password']; ?></p>
            <p> <strong>First Name: </strong><?php echo $user_data['firstName']; ?></p>
            <p> <strong>Last Name: </strong><?php echo $user_data['lastName']; ?></p>
            <p> <strong>Address: </strong><?php echo $user_data['address']; ?></p>
            <p> <strong>Phone: </strong><?php echo $user_data['phone']; ?></p>
          </div>
          <div class="profile-details profile-courses">
            <span>
              <h3>Courses</h3>
              <?php
              if ($notifications) {
                $name = $notifications['name'];
                $semester = $notifications["semester_name"];
                echo "<div class='notification-text'>The $semester block of $name is available for enrollment!</div>";
              }
              ?>
            </span>
            <?php
            if (empty($course_data)){echo "<div class='course'>No Course Currently Enrolled         <p><a href='courseregistry.php'>Click Here to Register</a></p>
              </div>";};
            foreach ($course_data as $course) {
              $name = $course["name"];
              $semester = $course["semester_name"];
              $active_course_id = $course["active_course_id"];
              $user_id = $user_data["id"];
              // echo "<script>console.log('Debug Objects: " . $course["name"] . $course["semester_name"] . "' );</script>";
              echo "<div class='course'>
            Course: $name <br/>
            Semester: $semester
            <form action='unenrollcourse.php' method='post'>
            <input name='course' id='course' value='$active_course_id' />
            <input name='user' id='user' value='$user_id' />
            <button>Unenroll</button>
            </form>
            </div>";
            }
            ?>
          </div>
        </div>




</body>

</html>
</div>
<div class="col-sm-2 sidenav">
  <div class="well">
    <p>ADS</p>
  </div>
  <div class="well">
    <p>ADS</p>
  </div>
</div>
</div>
</div>


<footer class="container-fluid text-center">
  <p>Copyright @ Angel Estevez 2024</p>
</footer>

</body>

</html>